const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 5000;

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'))
})

app.post('/formdata', (req,res)=>{
    const {num1, num2, operation} = req.body;
    let result = 0;

    switch(operation){
        case "+":{
            result = Number(num1)+Number(num2);
            break;
        }
        case "*":{
            result = Number(num1)*Number(num2);
            break;
        }
        case "-":{
            result = Number(num1)-Number(num2);
            break;
        }
        case "/":{
            result = Number(num1)/Number(num2);
            break;
        }
    }

    const resData = {
        score: result,
    }

    res.json(resData);
})

app.listen(port, ()=>{
    console.log(`Server is listening on port: ${port}`);
})
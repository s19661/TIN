var licznik = 0;
				  do {
					  prompt ("To jest petla");
					  licznik++;
				  }
				  while (licznik < 10);
				  prompt("Koniec pętli");


function readTable (tab) {
  for (var i = 0; i < tab.length; i++) {
    console.log(tab[i]);
  }
};
var fruit = [
  "BANAN",
  "JABŁKO",
  "ŚLIWKA",
  "POMELO",
  "TRUSKAWKA",
];

readTable(fruit);

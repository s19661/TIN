
const tab = ["Polsko-Japońska", "Akademia", "Technik", "Komputerowych"];
function tablica(tab) {
  return(tab);
}
alert (tablica(tab).join(""));

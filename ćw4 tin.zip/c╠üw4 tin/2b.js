var x;
  alert ("Podaj numer gabinetu");

  if(x % 3 == 1) {
    prompt("gabinet jest na parterze");
  }
  else if(x % 3 == 2) {
    prompt("gabinet jest na pierwszym piętrze");
  }
  else {
    prompt("gabinet jest na drugim piętrze");
  }

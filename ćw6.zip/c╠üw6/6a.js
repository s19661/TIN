//6a
var student = {
  imie: "Oliwia",
  nazwisko: "Jarosz",
  nr_indeksu: "s19661"
};

console.log("Dane nowego studenta: ");
console.log(JSON.stringify(student));

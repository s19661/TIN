//6b
var student1 = {
  imie: "Oliwia",
  nazwisko: "Jarosz",
  nr_indeksu: "s19661"
};

console.log(student1.imie + " " + student1.nazwisko + " " + student1.nr_indeksu);

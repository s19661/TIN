var student_s19661 = {imie:"Oliwia", nazwisko: "Jarosz", index:"s19661", oceny:[4, 3, 5, 5]};

var total = 0;
for(var i = 0; i < student_s19661.oceny.length; i++){
  total += student_s19661.oceny.length;
}
var avg = total / student_s19661.oceny.length;

console.log(student_s19661);
console.log("srednia ocen:", avg);

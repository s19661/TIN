silA = silnia(1);
silB = silnia(2);
silC = silnia(3);
silD = silnia(4);
function silnia(n){
  if ((n == 0) || (n == 1))
  return 1;
  else{
    var wynik = (n * silnia(n-1));
    return wynik;
  }
}
document.write(silA + "<br>");
document.write(silB + "<br>");
document.write(silC + "<br>");
document.write(silD + "<br>");
